Deadline: Pertemuan depan (5 September)

Buatlah website portfolio anda dalam bentuk HTML yang terdapat:
1. Nama anda
2. Deskripsi anda
3. Riwayat Pendidikan dari SD sampai S1 (Sekarang)
    Nama sekolah
    Kota
    tahun masuk
    tahun keluar
    logo/gambar
    dll
4. Riwayat Prestasi
    Nama lomba
    juara berapa
    tahun
    dll
5. Hobi
    nama hobi
    gambar kegiatan
6. Top 3 movies 
    Cover
    Judul
    kenapa bagus

Syarat: 
    1. Buat seindah mungkin
    2. tidak boleh pakai javascript
    3. semua dalam satu .html
    4. tidak boleh memakai css framework